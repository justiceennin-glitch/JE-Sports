function toggleMenu(){document.getElementById('nav')?.classList.toggle('open')}
function getPredictions(){try{return JSON.parse(localStorage.getItem('jeSportsPredictions')||'[]')}catch(e){return[]}}
function renderPredictions(){
 const box=document.getElementById('predictionCards'), empty=document.getElementById('emptyPredictions');
 if(!box)return;
 const data=getPredictions();
 box.innerHTML=data.map(p=>`<article class="match-card">
 <div class="league">${escapeHtml(p.league)}</div>
 <div class="teams"><b>${escapeHtml(p.home)}</b><span>VS</span><b>${escapeHtml(p.away)}</b></div>
 <div class="pick"><small>JE PICK</small><strong>${escapeHtml(p.pick)}</strong><em>Confidence: ${escapeHtml(p.confidence)}%</em></div>
 <div class="markets">${(p.markets||[]).map(m=>`<span>${escapeHtml(m)}</span>`).join('')}</div>
 </article>`).join('');
 empty.hidden=data.length>0;
}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
document.addEventListener('DOMContentLoaded',()=>{const t=document.getElementById('today');if(t)t.textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric',year:'numeric'});renderPredictions()});